import 'package:campus_mobile_experimental/ui/notifications/notifications_list_view.dart';
import 'package:flutter/material.dart';

class NotificationsTabView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return NotificationsListView();
  }
}
