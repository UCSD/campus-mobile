/// Constant Values
const double LOCATION_FONT_SIZE = 17;
const double PROGRESS_BAR_HEIGHT = 12;
const double PROGRESS_BAR_WIDTH = 325;
const double TITLE_SIDE_PADDINGS = 16;
const double TITLE_BOTTOM_PADDING = 5;
const double BORDER_RADIUS = 15;
const double DATA_UNAVAILABLE_TOP_PADDING = 10;
const int BACKGROUND_GREY_SHADE = 200;