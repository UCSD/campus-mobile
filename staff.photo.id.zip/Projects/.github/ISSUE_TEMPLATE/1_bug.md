---
name: Bug report
about: Submit a bug report.
title: ''
labels: ''
assignees: ''

---

- [ ] Pull from upstream to get the latest code
- [ ] Checkout the feature branch
- [ ] Compile and run the code
- [ ] Reproduce the bug
- [ ] Fix the bug
- [ ] Test locally on a device
- [ ] Create Pull Request