---
name: Feature request
about: Suggest a new idea for Flutter.
title: ''
labels: ''
assignees: ''

---

- [ ] Pull from upstream to get the latest code
- [ ] Checkout the feature branch
- [ ] Compile and run the code
- [ ] Develop the feature
- [ ] Test locally on a device
- [ ] Create Pull Request